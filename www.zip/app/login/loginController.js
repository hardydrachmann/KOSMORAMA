angular.module('kosmoramaApp').controller('LoginController', function($scope) {

  $scope.password = '';

  $scope.login = function() {

    // window.location.hostname.concat('#/home');
    // console.log($scope.password);

  };

});
