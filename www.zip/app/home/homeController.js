angular.module('kosmoramaApp').controller('HomeController', function($scope, $state) {
  $scope.data = 'home data';
});
