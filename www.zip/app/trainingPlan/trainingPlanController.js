angular.module('kosmoramaApp').controller('TrainingPlanController', function($scope, $state) {
  $scope.data = 'trainingplan data';
});
